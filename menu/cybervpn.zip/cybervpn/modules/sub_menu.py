from cybervpn import *

@bot.on(events.CallbackQuery(data=b'sub_menu'))
async def sub_menu(event):
    user_id = str(event.sender_id)
    first_name = event.sender.first_name
    last_name = event.sender.last_name if event.sender.last_name else ""
            if level == "user":
                tombol = [    
    [Button.inline("MENU SSH","ssh"),
    Button.inline("MENU VMESS","vmess-member")],
    [Button.inline("MENU VLESS","vless-member"),
    Button.inline("MENU TROJAN","trojan-member")],
    [Button.inline("Refresh","menu")]]
  await event.edit(buttons=tombol)